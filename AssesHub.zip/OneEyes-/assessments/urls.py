from django.urls import path
from .views import (
    AssessmentCatalogView, AssessmentDetailView, AssessmentTakeView, AssessmentSubmitView,
    StudentSubmissionsListView, SubmissionDetailView, ManageAssessmentsView, AssessmentCreateView,
    AssessmentEditView, AssessmentDeleteView, InstructorSubmissionsListView, SubmissionEvaluateView,
    StudentPerformanceView, EnterAssessmentView, LogMalpracticeView
)

urlpatterns = [
    path('catalog/', AssessmentCatalogView.as_view(), name='assessment_catalog'),
    path('<int:pk>/', AssessmentDetailView.as_view(), name='assessment_detail'),
    path('<int:pk>/take/', AssessmentTakeView.as_view(), name='assessment_take'),
    path('<int:pk>/submit/', AssessmentSubmitView.as_view(), name='assessment_submit'),
    path('submissions/', StudentSubmissionsListView.as_view(), name='student_submissions'),
    path('submissions/<int:pk>/', SubmissionDetailView.as_view(), name='submission_detail'),
    path('manage/', ManageAssessmentsView.as_view(), name='manage_assessments'),
    path('create/', AssessmentCreateView.as_view(), name='assessment_create'),
    path('<int:pk>/edit/', AssessmentEditView.as_view(), name='assessment_edit'),
    path('<int:pk>/delete/', AssessmentDeleteView.as_view(), name='assessment_delete'),
    path('instructor/submissions/', InstructorSubmissionsListView.as_view(), name='instructor_submissions'),
    path('submissions/<int:pk>/evaluate/', SubmissionEvaluateView.as_view(), name='submission_evaluate'),
    path('instructor/performance/', StudentPerformanceView.as_view(), name='student_performance'),
    path('enter/', EnterAssessmentView.as_view(), name='assessment_enter'),
    path('<int:pk>/log-malpractice/', LogMalpracticeView.as_view(), name='log_malpractice'),
]
