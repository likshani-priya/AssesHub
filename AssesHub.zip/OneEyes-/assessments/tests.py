from django.test import TestCase
from django.urls import reverse
from django.contrib.auth import get_user_model
from .models import Assessment, Question, MCQOption, Submission, Answer

User = get_user_model()

class AssessmentFlowTests(TestCase):
    def setUp(self):
        # Create users
        self.instructor = User.objects.create_user(
            email='inst@test.com', password='password', full_name='Teacher', role='instructor'
        )
        self.student = User.objects.create_user(
            email='stud@test.com', password='password', full_name='Learner', role='student'
        )
        
        # Create assessment
        self.assessment = Assessment.objects.create(
            title='Intro MCQ Quiz',
            description='Test description',
            duration=30,
            subject='Math',
            assessment_type='quiz',
            is_published=True,
            created_by=self.instructor
        )
        
        # MCQ Question
        self.q_mcq = Question.objects.create(
            assessment=self.assessment,
            text='What is 2+2?',
            question_type='mcq',
            points=5
        )
        self.opt_wrong = MCQOption.objects.create(question=self.q_mcq, option_text='3', is_correct=False)
        self.opt_correct = MCQOption.objects.create(question=self.q_mcq, option_text='4', is_correct=True)

    def test_mcq_auto_grading_success(self):
        self.client.login(email='stud@test.com', password='password')
        submit_url = reverse('assessment_submit', args=[self.assessment.id])
        
        # Submit correct MCQ answer
        response = self.client.post(submit_url, {
            f'question_{self.q_mcq.id}': self.opt_correct.id
        })
        self.assertEqual(response.status_code, 302)
        
        # Verify attempt is auto-evaluated and correct score is saved
        submission = Submission.objects.get(student=self.student, assessment=self.assessment)
        self.assertEqual(submission.status, 'completed')
        self.assertEqual(submission.score, 5)
        
    def test_mcq_auto_grading_incorrect(self):
        self.client.login(email='stud@test.com', password='password')
        submit_url = reverse('assessment_submit', args=[self.assessment.id])
        
        # Submit incorrect MCQ answer
        response = self.client.post(submit_url, {
            f'question_{self.q_mcq.id}': self.opt_wrong.id
        })
        self.assertEqual(response.status_code, 302)
        
        # Verify attempt is auto-evaluated and score is 0
        submission = Submission.objects.get(student=self.student, assessment=self.assessment)
        self.assertEqual(submission.status, 'completed')
        self.assertEqual(submission.score, 0)

    def test_mixed_assessment_manual_grading_flow(self):
        # Add a written short answer question to the assessment
        q_written = Question.objects.create(
            assessment=self.assessment,
            text='Explain photosynthesis in one sentence.',
            question_type='short_answer',
            points=10
        )
        
        self.client.login(email='stud@test.com', password='password')
        submit_url = reverse('assessment_submit', args=[self.assessment.id])
        
        # Submit attempts (correct MCQ + written text)
        response = self.client.post(submit_url, {
            f'question_{self.q_mcq.id}': self.opt_correct.id,
            f'question_{q_written.id}': 'Photosynthesis converts sunlight into energy.'
        })
        self.assertEqual(response.status_code, 302)
        
        # Verify submission status is pending (needs manual grading for the written part)
        submission = Submission.objects.get(student=self.student, assessment=self.assessment)
        self.assertEqual(submission.status, 'pending')
        # MCQ is evaluated internally, but final score is hidden (0 pts) while pending
        self.assertEqual(submission.score, 0)
        
        # Now, log in as instructor and perform evaluation
        self.client.login(email='inst@test.com', password='password')
        evaluate_url = reverse('submission_evaluate', args=[submission.id])
        
        # Fetch the Answer objects created for this submission to assign marks
        ans_written = Answer.objects.get(submission=submission, question=q_written)
        
        # Submit score for the written answer
        response = self.client.post(evaluate_url, {
            f'score_{ans_written.id}': 8,  # award 8 out of 10 points
        })
        self.assertEqual(response.status_code, 302)
        
        # Verify final submission score is updated (5 MCQ + 8 Written = 13) and status is evaluated
        submission.refresh_from_db()
        self.assertEqual(submission.status, 'completed')
        self.assertEqual(submission.score, 13)
