from django import forms
from .models import Assessment, Question

class AssessmentForm(forms.ModelForm):
    class Meta:
        model = Assessment
        fields = ['title', 'assignment_id', 'description', 'duration', 'subject', 'assessment_type', 'is_published']
        widgets = {
            'title': forms.TextInput(attrs={'class': 'form-control', 'placeholder': 'Enter title'}),
            'assignment_id': forms.TextInput(attrs={'class': 'form-control', 'placeholder': 'Enter Assignment ID (Example: AS1)'}),
            'description': forms.Textarea(attrs={'class': 'form-control', 'rows': 3, 'placeholder': 'Enter description'}),
            'duration': forms.NumberInput(attrs={'class': 'form-control', 'placeholder': 'Duration in minutes', 'min': 1}),
            'subject': forms.TextInput(attrs={'class': 'form-control', 'placeholder': 'e.g. Computer Science'}),
            'assessment_type': forms.Select(attrs={'class': 'form-select'}),
            'is_published': forms.CheckboxInput(attrs={'class': 'form-check-input', 'id': 'is_published_checkbox'}),
        }

    def __init__(self, *args, **kwargs):
        super().__init__(*args, **kwargs)
        self.fields['assignment_id'].required = True
        self.fields['title'].required = True
        self.fields['assessment_type'].required = True
        self.fields['description'].required = True
        self.fields['duration'].required = True

    def clean_assignment_id(self):
        assignment_id = self.cleaned_data.get('assignment_id', '').strip()
        if not assignment_id:
            raise forms.ValidationError("Assignment ID is required.")
        
        qs = Assessment.objects.filter(assignment_id__iexact=assignment_id)
        if self.instance and self.instance.pk:
            qs = qs.exclude(pk=self.instance.pk)
        
        if qs.exists():
            raise forms.ValidationError("This Assignment ID already exists. Please choose a unique ID.")
        
        return assignment_id
