from django.contrib import admin
from django.utils.html import format_html
from django.utils import timezone
from .models import Assessment, Question, MCQOption, Submission, Answer, ActivityLog, MalpracticeLog


def format_ist(dt):
    """Format a datetime to IST display string for admin."""
    if not dt:
        return "-"
    ist = timezone.localtime(dt)
    return ist.strftime("%d %b %Y, %I:%M %p IST")


class AssessmentAdmin(admin.ModelAdmin):
    list_display = ('title', 'assignment_id', 'subject', 'get_assessment_type', 'instructor', 'is_published', 'get_created_at')
    search_fields = ('title', 'assignment_id', 'created_by__email', 'created_by__full_name')
    list_filter = ('assessment_type', 'is_published', 'subject', 'created_by')
    ordering = ('-created_at',)

    def instructor(self, obj):
        return obj.created_by.full_name if obj.created_by else "None"
    instructor.short_description = 'Instructor'

    def get_assessment_type(self, obj):
        return obj.get_assessment_type_display()
    get_assessment_type.short_description = 'Type'

    def get_created_at(self, obj):
        return format_ist(obj.created_at)
    get_created_at.short_description = 'Created At (IST)'
    get_created_at.admin_order_field = 'created_at'


class QuestionAdmin(admin.ModelAdmin):
    list_display = ('get_text', 'assessment', 'question_type', 'points')
    search_fields = ('text', 'assessment__title')
    list_filter = ('question_type', 'assessment__subject')
    ordering = ('assessment', 'id')

    def get_text(self, obj):
        return obj.text[:50] + '...' if len(obj.text) > 50 else obj.text
    get_text.short_description = 'Question Text'


class MCQOptionAdmin(admin.ModelAdmin):
    list_display = ('option_text', 'question', 'is_correct')
    search_fields = ('option_text', 'question__text')
    list_filter = ('is_correct',)
    ordering = ('question', 'id')


class SubmissionAdmin(admin.ModelAdmin):
    list_display = ('student_name', 'get_assignment_id', 'get_assessment_type', 'get_status_display_label', 'score', 'get_submitted_at')
    search_fields = ('student__email', 'student__full_name', 'assessment__assignment_id', 'assessment__title')
    list_filter = ('status', 'assessment__assessment_type', 'submitted_at')
    ordering = ('-submitted_at',)

    def student_name(self, obj):
        return obj.student.full_name if obj.student else "N/A"
    student_name.short_description = 'Student'
    student_name.admin_order_field = 'student__full_name'

    def get_assignment_id(self, obj):
        return obj.assessment.assignment_id if obj.assessment else "N/A"
    get_assignment_id.short_description = 'Assignment ID'
    get_assignment_id.admin_order_field = 'assessment__assignment_id'

    def get_assessment_type(self, obj):
        return obj.assessment.get_assessment_type_display() if obj.assessment else "N/A"
    get_assessment_type.short_description = 'Assessment Type'
    get_assessment_type.admin_order_field = 'assessment__assessment_type'

    def get_status_display_label(self, obj):
        status_map = {
            'pending': ('⏳ Pending Evaluation', '#6c757d'),
            'completed': ('✅ Evaluated', '#198754'),
            'malpractice': ('🚨 Malpractice', '#dc3545'),
            'invalid_student': ('⚠️ Invalid Student', '#fd7e14'),
        }
        label, color = status_map.get(obj.status, (obj.status, '#6c757d'))
        return format_html('<span style="color: {}; font-weight: bold;">{}</span>', color, label)
    get_status_display_label.short_description = 'Evaluation Status'
    get_status_display_label.admin_order_field = 'status'

    def get_submitted_at(self, obj):
        return format_ist(obj.submitted_at)
    get_submitted_at.short_description = 'Submitted At (IST)'
    get_submitted_at.admin_order_field = 'submitted_at'


class AnswerAdmin(admin.ModelAdmin):
    list_display = ('submission', 'question', 'score', 'is_evaluated')
    search_fields = ('submission__student__email', 'submission__student__full_name', 'question__text')
    list_filter = ('is_evaluated', 'question__question_type')
    ordering = ('submission', 'question')


class ActivityLogAdmin(admin.ModelAdmin):
    list_display = ('user', 'action', 'get_timestamp', 'get_details')
    search_fields = ('user__email', 'user__full_name', 'action', 'details')
    list_filter = ('action', 'timestamp')
    ordering = ('-timestamp',)

    def get_timestamp(self, obj):
        return format_ist(obj.timestamp)
    get_timestamp.short_description = 'Timestamp (IST)'
    get_timestamp.admin_order_field = 'timestamp'

    def get_details(self, obj):
        if obj.details:
            return obj.details[:50] + '...' if len(obj.details) > 50 else obj.details
        return ""
    get_details.short_description = 'Details'


class MalpracticeLogAdmin(admin.ModelAdmin):
    list_display = ('student', 'get_assignment_id', 'get_event_badge', 'get_timestamp')
    search_fields = ('student__email', 'student__full_name', 'assignment_id', 'assessment__title')
    # Only show TAB, COPY, PASTE events in admin (exclude BLUR/WINDOW_BLUR)
    list_filter = ('event_type', 'timestamp')
    ordering = ('-timestamp',)

    def get_queryset(self, request):
        # Exclude WINDOW_BLUR events from admin malpractice log
        qs = super().get_queryset(request)
        return qs.exclude(event_type='WINDOW_BLUR')

    def get_assignment_id(self, obj):
        return obj.assignment_id or (obj.assessment.assignment_id if obj.assessment else "N/A")
    get_assignment_id.short_description = 'Assignment ID'
    get_assignment_id.admin_order_field = 'assignment_id'

    def get_event_badge(self, obj):
        event_colors = {
            'TAB_SWITCH': '#ffc107',
            'COPY_ATTEMPT': '#dc3545',
            'PASTE_ATTEMPT': '#dc3545',
            'MALPRACTICE_FLAG': '#6f42c1',
            'RIGHT_CLICK': '#fd7e14',
            'FULLSCREEN_EXIT': '#0dcaf0',
        }
        color = event_colors.get(obj.event_type, '#6c757d')
        return format_html('<span style="background:{};color:#fff;padding:2px 8px;border-radius:4px;font-size:0.8rem;font-weight:bold;">{}</span>', color, obj.event_type)
    get_event_badge.short_description = 'Violation Event'

    def get_timestamp(self, obj):
        return format_ist(obj.timestamp)
    get_timestamp.short_description = 'Timestamp (IST)'
    get_timestamp.admin_order_field = 'timestamp'


admin.site.register(Assessment, AssessmentAdmin)
admin.site.register(Question, QuestionAdmin)
admin.site.register(MCQOption, MCQOptionAdmin)
admin.site.register(Submission, SubmissionAdmin)
admin.site.register(Answer, AnswerAdmin)
admin.site.register(ActivityLog, ActivityLogAdmin)
admin.site.register(MalpracticeLog, MalpracticeLogAdmin)
