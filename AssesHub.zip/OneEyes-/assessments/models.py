from django.db import models
from django.conf import settings

class Assessment(models.Model):
    TYPE_CHOICES = (
        ('mcq', 'MCQ'),
        ('exam', 'Exam'),
        ('test', 'Test'),
    )
    
    title = models.CharField(max_length=255)
    assignment_id = models.CharField(max_length=50, unique=True, null=True, blank=True)
    description = models.TextField(blank=True, null=True)
    duration = models.IntegerField(help_text="Duration in minutes")
    subject = models.CharField(max_length=100)
    assessment_type = models.CharField(max_length=20, choices=TYPE_CHOICES, default='mcq')
    is_published = models.BooleanField(default=False)
    created_by = models.ForeignKey(
        settings.AUTH_USER_MODEL, 
        on_delete=models.CASCADE, 
        related_name='created_assessments'
    )
    created_at = models.DateTimeField(auto_now_add=True)
    updated_at = models.DateTimeField(auto_now=True)

    def __str__(self):
        return self.title

    @property
    def total_points(self):
        return sum(q.points for q in self.questions.all())

class Question(models.Model):
    TYPE_CHOICES = (
        ('mcq', 'MCQ'),
        ('short_answer', 'Short Answer'),
        ('long_answer', 'Long Answer'),
    )
    
    assessment = models.ForeignKey(Assessment, on_delete=models.CASCADE, related_name='questions')
    text = models.TextField()
    question_type = models.CharField(max_length=20, choices=TYPE_CHOICES)
    points = models.IntegerField(default=1)

    def __str__(self):
        return f"{self.question_type.upper()} - {self.text[:50]}"

class MCQOption(models.Model):
    question = models.ForeignKey(Question, on_delete=models.CASCADE, related_name='options')
    option_text = models.CharField(max_length=255)
    is_correct = models.BooleanField(default=False)

    def __str__(self):
        return self.option_text

class Submission(models.Model):
    STATUS_CHOICES = (
        ('pending', 'Pending Evaluation'),
        ('completed', 'Evaluated'),
        ('malpractice', 'Malpractice'),
        ('invalid_student', 'Invalid Student'),
    )
    
    student = models.ForeignKey(
        settings.AUTH_USER_MODEL, 
        on_delete=models.CASCADE, 
        related_name='submissions'
    )
    assessment = models.ForeignKey(Assessment, on_delete=models.CASCADE, related_name='submissions')
    instructor = models.ForeignKey(
        settings.AUTH_USER_MODEL,
        on_delete=models.CASCADE,
        related_name='instructor_submissions',
        null=True,
        blank=True
    )
    submitted_at = models.DateTimeField(auto_now_add=True)
    status = models.CharField(max_length=20, choices=STATUS_CHOICES, default='pending')
    score = models.IntegerField(default=0)

    def __str__(self):
        return f"{self.student.full_name} - {self.assessment.title}"

    @property
    def percentage(self):
        total_points = self.assessment.total_points
        if total_points > 0:
            return round((self.score / total_points) * 100, 1)
        return 0.0

class Answer(models.Model):
    submission = models.ForeignKey(Submission, on_delete=models.CASCADE, related_name='answers')
    question = models.ForeignKey(Question, on_delete=models.CASCADE)
    selected_option = models.ForeignKey(MCQOption, on_delete=models.SET_NULL, null=True, blank=True)
    text_answer = models.TextField(blank=True, null=True)
    score = models.IntegerField(default=0)
    is_evaluated = models.BooleanField(default=False)

    def __str__(self):
        return f"Answer to {self.question.id} for submission {self.submission.id}"

class ActivityLog(models.Model):
    user = models.ForeignKey(
        settings.AUTH_USER_MODEL, 
        on_delete=models.SET_NULL, 
        null=True, 
        blank=True, 
        related_name='activity_logs'
    )
    action = models.CharField(max_length=255)
    timestamp = models.DateTimeField(auto_now_add=True)
    details = models.TextField(blank=True, null=True)

    def __str__(self):
        return f"{self.user} - {self.action} at {self.timestamp}"

class MalpracticeLog(models.Model):
    student = models.ForeignKey(
        settings.AUTH_USER_MODEL,
        on_delete=models.CASCADE,
        related_name='malpractice_logs'
    )
    assessment = models.ForeignKey(
        Assessment,
        on_delete=models.CASCADE,
        related_name='malpractice_logs'
    )
    assignment_id = models.CharField(max_length=50, null=True, blank=True)
    event_type = models.CharField(max_length=50)
    timestamp = models.DateTimeField(auto_now_add=True)

    def __str__(self):
        return f"{self.student.full_name} - {self.assessment.title} - {self.event_type} at {self.timestamp}"
