import json
from django.http import JsonResponse
from django.shortcuts import render, redirect
from django.views.generic import ListView, DetailView, CreateView, UpdateView, DeleteView, View
from django.contrib.auth.mixins import LoginRequiredMixin
from django.urls import reverse_lazy
from django.db import transaction
from django.db.models import Q, Avg, Count
from django.contrib import messages
from django.utils import timezone

from accounts.views import StudentRequiredMixin, InstructorRequiredMixin, log_user_activity
from .models import Assessment, Question, MCQOption, Submission, Answer, ActivityLog, MalpracticeLog
from .forms import AssessmentForm

# Custom get_object_or_404 implementation to prevent import issues
def get_object_or_404(klass, *args, **kwargs):
    from django.shortcuts import get_object_or_404 as dj_get_object_or_404
    return dj_get_object_or_404(klass, *args, **kwargs)

class AssessmentCatalogView(StudentRequiredMixin, ListView):
    model = Assessment
    template_name = 'assessments/catalog.html'
    context_object_name = 'assessments'
    paginate_by = 6

    def get_queryset(self):
        queryset = Assessment.objects.filter(is_published=True).order_by('-created_at')
        
        # Search
        q = self.request.GET.get('q')
        if q:
            queryset = queryset.filter(Q(title__icontains=q) | Q(description__icontains=q))
            
        # Subject Filter
        subject = self.request.GET.get('subject')
        if subject:
            queryset = queryset.filter(subject__iexact=subject)
            
        # Type Filter
        assessment_type = self.request.GET.get('type')
        if assessment_type:
            queryset = queryset.filter(assessment_type=assessment_type)
            
        return queryset

    def get_context_data(self, **kwargs):
        context = super().get_context_data(**kwargs)
        # Pass unique subjects list for filter dropdown
        context['subjects'] = Assessment.objects.filter(is_published=True).values_list('subject', flat=True).distinct()
        context['types'] = Assessment.TYPE_CHOICES
        context['current_q'] = self.request.GET.get('q', '')
        context['current_subject'] = self.request.GET.get('subject', '')
        context['current_type'] = self.request.GET.get('type', '')
        return context

class AssessmentDetailView(StudentRequiredMixin, DetailView):
    model = Assessment
    template_name = 'assessments/detail.html'
    context_object_name = 'assessment'

    def get_queryset(self):
        return Assessment.objects.filter(is_published=True)

class AssessmentTakeView(StudentRequiredMixin, View):
    template_name = 'assessments/take.html'

    def get(self, request, pk, *args, **kwargs):
        assessment = get_object_or_404(Assessment, pk=pk, is_published=True)
        
        # Check if student already submitted this
        if Submission.objects.filter(student=request.user, assessment=assessment).exists():
            messages.warning(request, "You have already completed this assessment.")
            return redirect('student_submissions')
            
        questions = assessment.questions.all().prefetch_related('options')
        
        tab_switch_count = MalpracticeLog.objects.filter(
            student=request.user,
            assessment=assessment,
            event_type__in=['TAB_SWITCH', 'WINDOW_BLUR']
        ).count()
        
        fullscreen_exit_count = MalpracticeLog.objects.filter(
            student=request.user,
            assessment=assessment,
            event_type='FULLSCREEN_EXIT'
        ).count()
        
        violations_count = MalpracticeLog.objects.filter(
            student=request.user,
            assessment=assessment
        ).count()
        
        return render(request, self.template_name, {
            'assessment': assessment,
            'questions': questions,
            'violations_count': violations_count,
            'tab_switch_count': tab_switch_count,
            'fullscreen_exit_count': fullscreen_exit_count,
        })

class AssessmentSubmitView(StudentRequiredMixin, View):
    def post(self, request, pk, *args, **kwargs):
        assessment = get_object_or_404(Assessment, pk=pk, is_published=True)
        
        # Double check submission existence to prevent resubmits
        if Submission.objects.filter(student=request.user, assessment=assessment).exists():
            messages.warning(request, "You have already submitted this assessment.")
            return redirect('student_submissions')
            
        questions = assessment.questions.all()
        
        with transaction.atomic():
            submission = Submission.objects.create(
                student=request.user,
                assessment=assessment,
                instructor=assessment.created_by,
                status='pending',
                score=0
            )
            
            has_written_questions = False
            total_score = 0
            
            for q in questions:
                # Get answer submitted by user
                param_name = f"question_{q.id}"
                
                if q.question_type == 'mcq':
                    option_id = request.POST.get(param_name)
                    selected_opt = None
                    score = 0
                    
                    if option_id:
                        try:
                            selected_opt = MCQOption.objects.get(id=int(option_id), question=q)
                            if selected_opt.is_correct:
                                score = q.points
                        except MCQOption.DoesNotExist:
                            pass
                            
                    Answer.objects.create(
                        submission=submission,
                        question=q,
                        selected_option=selected_opt,
                        score=score,
                        is_evaluated=True
                    )
                    total_score += score
                    
                else:
                    has_written_questions = True
                    text_ans = request.POST.get(param_name, '').strip()
                    Answer.objects.create(
                        submission=submission,
                        question=q,
                        text_answer=text_ans,
                        score=0,
                        is_evaluated=False
                    )
            
            # If the assessment only consists of MCQs, auto-evaluate and mark as completed
            if not has_written_questions:
                submission.status = 'completed'
                submission.score = total_score
                submission.save()
                
                log_user_activity(request.user, "Assessment Evaluated", f"Assessment '{assessment.title}' auto-evaluated. Score: {total_score} points.")
                messages.success(request, f"Assessment '{assessment.title}' submitted and auto-evaluated successfully! Score: {total_score}/{assessment.total_points}")
            else:
                submission.score = 0
                submission.status = 'pending'
                submission.save()
                log_user_activity(request.user, "Assessment Submitted", f"Submitted assessment '{assessment.title}'. Status: Pending Evaluation.")
                messages.success(request, f"Assessment '{assessment.title}' submitted successfully! Status: Pending Evaluation — instructor will review written answers.")
                
        return redirect('student_submissions')

class StudentSubmissionsListView(StudentRequiredMixin, ListView):
    model = Submission
    template_name = 'assessments/student_submissions.html'
    context_object_name = 'submissions'
    paginate_by = 10

    def get_queryset(self):
        return Submission.objects.filter(student=self.request.user).order_by('-submitted_at')

class SubmissionDetailView(LoginRequiredMixin, DetailView):
    model = Submission
    template_name = 'assessments/submission_detail.html'
    context_object_name = 'submission'

    def get_queryset(self):
        # Allow student to see their own submission, and instructor to see submissions to their assessments
        user = self.request.user
        if user.role == 'student':
            return Submission.objects.filter(student=user)
        elif user.role == 'instructor':
            return Submission.objects.filter(assessment__created_by=user)
        else:
            return Submission.objects.all()

    def get_context_data(self, **kwargs):
        context = super().get_context_data(**kwargs)
        # Pass answer objects with prefetched options/questions
        context['answers'] = self.object.answers.all().select_related('question').prefetch_related('question__options')
        return context

class ManageAssessmentsView(InstructorRequiredMixin, ListView):
    model = Assessment
    template_name = 'assessments/manage.html'
    context_object_name = 'assessments'
    paginate_by = 10

    def get_queryset(self):
        return Assessment.objects.filter(created_by=self.request.user).order_by('-created_at')

class AssessmentCreateView(InstructorRequiredMixin, View):
    template_name = 'assessments/create.html'

    def get(self, request, *args, **kwargs):
        form = AssessmentForm()
        return render(request, self.template_name, {'form': form})

    def post(self, request, *args, **kwargs):
        form = AssessmentForm(request.POST)
        questions_json = request.POST.get('questions_json', '[]')
        
        if form.is_valid():
            try:
                questions_data = json.loads(questions_json)
            except json.JSONDecodeError:
                messages.error(request, "Invalid questions format submitted.")
                return render(request, self.template_name, {'form': form})
                
            if not questions_data:
                messages.error(request, "You must add at least one question to the assessment.")
                return render(request, self.template_name, {'form': form})
                
            with transaction.atomic():
                assessment = form.save(commit=False)
                assessment.created_by = request.user
                assessment.save()
                
                for q_data in questions_data:
                    q = Question.objects.create(
                        assessment=assessment,
                        text=q_data['text'],
                        question_type=q_data['type'],
                        points=int(q_data.get('points', 1))
                    )
                    
                    if q_data['type'] == 'mcq':
                        for opt in q_data.get('options', []):
                            MCQOption.objects.create(
                                question=q,
                                option_text=opt['text'],
                                is_correct=opt.get('is_correct', False)
                            )
                            
                log_user_activity(request.user, "Assessment Created", f"Created assessment '{assessment.title}'")
                messages.success(request, f"Assessment '{assessment.title}' created successfully!")
                return redirect('manage_assessments')
        else:
            messages.error(request, "Please correct the errors in the form below.")
            
        return render(request, self.template_name, {'form': form})

class AssessmentEditView(InstructorRequiredMixin, View):
    template_name = 'assessments/edit.html'

    def get(self, request, pk, *args, **kwargs):
        assessment = get_object_or_404(Assessment, pk=pk, created_by=request.user)
        form = AssessmentForm(instance=assessment)
        
        # Serialize existing questions and options to JSON for frontend editor
        questions_list = []
        for q in assessment.questions.all().prefetch_related('options'):
            q_data = {
                'text': q.text,
                'type': q.question_type,
                'points': q.points,
                'options': [{'text': opt.option_text, 'is_correct': opt.is_correct} for opt in q.options.all()]
            }
            questions_list.append(q_data)
            
        questions_json = json.dumps(questions_list)
        
        return render(request, self.template_name, {
            'form': form,
            'assessment': assessment,
            'questions_json': questions_json
        })

    def post(self, request, pk, *args, **kwargs):
        assessment = get_object_or_404(Assessment, pk=pk, created_by=request.user)
        form = AssessmentForm(request.POST, instance=assessment)
        questions_json = request.POST.get('questions_json', '[]')
        
        if form.is_valid():
            try:
                questions_data = json.loads(questions_json)
            except json.JSONDecodeError:
                messages.error(request, "Invalid questions format submitted.")
                return render(request, self.template_name, {'form': form, 'assessment': assessment})
                
            if not questions_data:
                messages.error(request, "You must add at least one question to the assessment.")
                return render(request, self.template_name, {'form': form, 'assessment': assessment})
                
            with transaction.atomic():
                assessment = form.save()
                
                # Delete existing questions and recreate
                assessment.questions.all().delete()
                
                for q_data in questions_data:
                    q = Question.objects.create(
                        assessment=assessment,
                        text=q_data['text'],
                        question_type=q_data['type'],
                        points=int(q_data.get('points', 1))
                    )
                    
                    if q_data['type'] == 'mcq':
                        for opt in q_data.get('options', []):
                            MCQOption.objects.create(
                                question=q,
                                option_text=opt['text'],
                                is_correct=opt.get('is_correct', False)
                            )
                            
                log_user_activity(request.user, "Assessment Updated", f"Updated assessment '{assessment.title}'")
                messages.success(request, f"Assessment '{assessment.title}' updated successfully!")
                return redirect('manage_assessments')
        else:
            messages.error(request, "Please correct the errors in the form below.")
            
        return render(request, self.template_name, {'form': form, 'assessment': assessment})

class AssessmentDeleteView(InstructorRequiredMixin, DeleteView):
    model = Assessment
    success_url = reverse_lazy('manage_assessments')
    
    def get_queryset(self):
        return Assessment.objects.filter(created_by=self.request.user)
        
    def delete(self, request, *args, **kwargs):
        assessment = self.get_object()
        log_user_activity(request.user, "Assessment Deleted", f"Deleted assessment '{assessment.title}'")
        messages.success(request, f"Assessment '{assessment.title}' deleted successfully.")
        return super().delete(request, *args, **kwargs)

class InstructorSubmissionsListView(InstructorRequiredMixin, ListView):
    model = Submission
    template_name = 'assessments/instructor_submissions.html'
    context_object_name = 'submissions'
    paginate_by = 10

    def get_queryset(self):
        # Only get submissions to assessments created by this instructor
        queryset = Submission.objects.filter(assessment__created_by=self.request.user).order_by('-submitted_at')
        
        # Filter by status
        status = self.request.GET.get('status')
        # Map URL param 'evaluated' to the DB value 'completed'
        status_map = {'pending': 'pending', 'evaluated': 'completed', 'malpractice': 'malpractice', 'invalid_student': 'invalid_student'}
        if status in status_map:
            queryset = queryset.filter(status=status_map[status])
            
        return queryset

    def get_context_data(self, **kwargs):
        context = super().get_context_data(**kwargs)
        context['current_status'] = self.request.GET.get('status', 'all')
        return context

class SubmissionEvaluateView(InstructorRequiredMixin, View):
    template_name = 'assessments/evaluate.html'

    def get(self, request, pk, *args, **kwargs):
        submission = get_object_or_404(Submission, pk=pk, assessment__created_by=request.user)
        answers = submission.answers.all().select_related('question')
        return render(request, self.template_name, {
            'submission': submission,
            'answers': answers,
        })

    def post(self, request, pk, *args, **kwargs):
        submission = get_object_or_404(Submission, pk=pk, assessment__created_by=request.user)
        answers = submission.answers.all().select_related('question')
        action = request.POST.get('evaluation_action', 'evaluate')
        
        with transaction.atomic():
            if action == 'invalid_student':
                # Mark as invalid student, evaluation stopped, no marks calculated
                submission.status = 'invalid_student'
                submission.score = 0
                for ans in answers:
                    if ans.question.question_type != 'mcq':
                        ans.score = 0
                        ans.is_evaluated = True
                        ans.save()
                submission.save()
                
                log_user_activity(request.user, "Marked Submission Invalid Student", f"Submission for {submission.student.full_name} marked as Invalid Student.")
                messages.error(request, f"Submission for {submission.student.full_name} has been marked as Invalid Student.")
                
            elif action == 'malpractice':
                # Mark as malpractice: score is automatically set to 0, status = malpractice
                # Mark all non-evaluated written answers as evaluated (score 0)
                for ans in answers:
                    if ans.question.question_type != 'mcq':
                        ans.score = 0
                        ans.is_evaluated = True
                        ans.save()

                submission.score = 0  # Malpractice always sets marks to 0
                submission.status = 'malpractice'
                submission.save()

                # Save malpractice record in MalpracticeLog
                MalpracticeLog.objects.create(
                    student=submission.student,
                    assessment=submission.assessment,
                    assignment_id=submission.assessment.assignment_id,
                    event_type='MALPRACTICE_FLAG'
                )

                log_user_activity(request.user, "Flagged Submission Malpractice", f"Submission for {submission.student.full_name} flagged for Malpractice. Score set to 0.")
                messages.warning(request, f"Submission for {submission.student.full_name} has been marked as Malpractice. Score set to 0.")
                
            else: # Standard evaluation
                total_score = 0
                for ans in answers:
                    if ans.question.question_type != 'mcq':
                        score_param = f"score_{ans.id}"
                        score_val = request.POST.get(score_param, '0')
                        try:
                            score = int(score_val)
                        except ValueError:
                            score = 0
                        if score > ans.question.points:
                            score = ans.question.points
                        elif score < 0:
                            score = 0
                        ans.score = score
                        ans.is_evaluated = True
                        ans.save()
                        total_score += score
                    else:
                        total_score += ans.score
                
                submission.score = total_score
                submission.status = 'completed'
                submission.save()
                
                log_user_activity(request.user, "Submission Evaluated", f"Evaluated student {submission.student.full_name}'s attempt for '{submission.assessment.title}'")
                messages.success(request, f"Evaluated {submission.student.full_name}'s submission successfully. Final Score: {total_score}/{submission.assessment.total_points}")
                
        return redirect('instructor_dashboard')

class StudentPerformanceView(InstructorRequiredMixin, ListView):
    model = Submission
    template_name = 'assessments/student_performance.html'
    context_object_name = 'attempts'
    paginate_by = 15

    def get_queryset(self):
        # Fetch attempts for this instructor's assessments, excluding invalid students
        queryset = Submission.objects.filter(
            assessment__created_by=self.request.user
        ).exclude(status='invalid_student').order_by('-submitted_at')
        
        # Search student name or email
        q = self.request.GET.get('q')
        if q:
            queryset = queryset.filter(
                Q(student__full_name__icontains=q) | 
                Q(student__email__icontains=q) |
                Q(assessment__title__icontains=q)
            )
            
        return queryset

    def get_context_data(self, **kwargs):
        context = super().get_context_data(**kwargs)
        user = self.request.user
        
        # Get all assessments created by this instructor
        assessments = Assessment.objects.filter(created_by=user).order_by('-created_at')
        
        assessment_analytics_list = []
        for asm in assessments:
            # Submissions for this specific assessment
            submissions = asm.submissions.all()
            
            total_attempts = submissions.count()
            completed_count = submissions.filter(status='completed').count()
            malpractice_count = submissions.filter(status='malpractice').count()
            invalid_count = submissions.filter(status='invalid_student').count()
            
            # Evaluated submissions: Evaluated (completed) + Malpractice.
            # Exclude invalid_student and pending (since pending are not yet evaluated).
            graded_subs = submissions.filter(status__in=['completed', 'malpractice'])
            
            total_points = asm.total_points
            
            if graded_subs.exists() and total_points > 0:
                avg_score = graded_subs.aggregate(Avg('score'))['score__avg'] or 0
                avg_percentage = (avg_score / total_points) * 100
                
                # Get highest and lowest scores
                scores_list = [s.score for s in graded_subs]
                highest_score = max(scores_list)
                highest_percentage = (highest_score / total_points) * 100
                
                lowest_score = min(scores_list)
                lowest_percentage = (lowest_score / total_points) * 100
            else:
                avg_score = 0.0
                avg_percentage = 0.0
                highest_score = 0
                highest_percentage = 0.0
                lowest_score = 0
                lowest_percentage = 0.0
                
            assessment_analytics_list.append({
                'assessment': asm,
                'total_attempts': total_attempts,
                'completed_count': completed_count,
                'malpractice_count': malpractice_count,
                'invalid_count': invalid_count,
                'avg_score': round(avg_score, 1),
                'avg_percentage': round(avg_percentage, 1),
                'highest_score': highest_score,
                'highest_percentage': round(highest_percentage, 1),
                'lowest_score': lowest_score,
                'lowest_percentage': round(lowest_percentage, 1),
            })
            
        context.update({
            'assessment_analytics_list': assessment_analytics_list,
            'current_q': self.request.GET.get('q', ''),
        })
        return context

class EnterAssessmentView(StudentRequiredMixin, View):
    def post(self, request, *args, **kwargs):
        assignment_id = request.POST.get('assignment_id', '').strip()
        if not assignment_id:
            messages.error(request, "Please enter an Assignment ID.")
            return redirect('student_dashboard')
            
        assessment = Assessment.objects.filter(assignment_id__iexact=assignment_id, is_published=True).first()
        if not assessment:
            messages.error(request, "Invalid Assignment ID")
            return redirect('student_dashboard')
            
        # Redirect to the assessment take view
        return redirect('assessment_take', pk=assessment.pk)

class LogMalpracticeView(StudentRequiredMixin, View):
    def post(self, request, pk, *args, **kwargs):
        assessment = get_object_or_404(Assessment, pk=pk, is_published=True)
        event_type = request.POST.get('event_type')
        valid_events = ['TAB_SWITCH', 'WINDOW_BLUR', 'COPY_ATTEMPT', 'PASTE_ATTEMPT', 'RIGHT_CLICK', 'FULLSCREEN_EXIT']
        if event_type in valid_events:
            # Exclude/ignore WINDOW_BLUR from being logged
            if event_type == 'WINDOW_BLUR':
                return JsonResponse({'status': 'ignored_blur'})
                
            MalpracticeLog.objects.create(
                student=request.user,
                assessment=assessment,
                assignment_id=assessment.assignment_id,
                event_type=event_type
            )
            # Count violations excluding WINDOW_BLUR
            violation_count = MalpracticeLog.objects.filter(
                student=request.user,
                assessment=assessment
            ).exclude(event_type='WINDOW_BLUR').count()
            return JsonResponse({'status': 'logged', 'violation_count': violation_count})
        return JsonResponse({'status': 'ignored'}, status=400)
