from django.core.management.base import BaseCommand
from accounts.models import User

class Command(BaseCommand):
    help = 'Creates or updates the default superuser/admin account Virat for development/demo purposes'

    def handle(self, *args, **options):
        email = 'virat@gmail.com'
        full_name = 'Virat'
        password = '1234'
        
        if User.objects.filter(email=email).exists():
            user = User.objects.get(email=email)
            user.set_password(password)
            user.full_name = full_name
            user.is_staff = True
            user.is_superuser = True
            user.role = 'admin'
            user.save()
            self.stdout.write(self.style.SUCCESS(f"Superuser '{full_name}' ({email}) already exists. Reset password to '{password}' and role to 'admin'."))
        else:
            User.objects.create_superuser(
                email=email,
                password=password,
                full_name=full_name
            )
            self.stdout.write(self.style.SUCCESS(f"Superuser '{full_name}' ({email}) created successfully with password '{password}'."))
