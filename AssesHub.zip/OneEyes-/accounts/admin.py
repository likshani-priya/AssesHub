from django.contrib import admin
from django.contrib.auth.admin import UserAdmin as DjangoUserAdmin
from .models import User, StudentProfile, InstructorProfile, InstituteSetting

admin.site.site_header = "AssesHub Admin"
admin.site.site_title = "AssesHub Admin Portal"
admin.site.index_title = "Welcome to the AssesHub Admin Portal"

class UserAdmin(DjangoUserAdmin):
    ordering = ('email',)
    list_display = ('email', 'full_name', 'role', 'is_staff', 'is_active')
    list_filter = ('role', 'is_staff', 'is_active')
    search_fields = ('email', 'full_name')
    fieldsets = (
        (None, {'fields': ('email', 'password')}),
        ('Personal Info', {'fields': ('full_name', 'profile_picture')}),
        ('Permissions', {'fields': ('role', 'is_active', 'is_staff', 'is_superuser', 'groups', 'user_permissions')}),
        ('Important Dates', {'fields': ('last_login', 'date_joined')}),
    )
    add_fieldsets = (
        (None, {
            'classes': ('wide',),
            'fields': ('email', 'full_name', 'role', 'password'),
        }),
    )

class StudentProfileAdmin(admin.ModelAdmin):
    list_display = ('user', 'enrollment_date')
    search_fields = ('user__email', 'user__full_name', 'bio')
    list_filter = ('enrollment_date',)
    ordering = ('-enrollment_date',)

class InstructorProfileAdmin(admin.ModelAdmin):
    list_display = ('user', 'department', 'office_hours')
    search_fields = ('user__email', 'user__full_name', 'department')
    list_filter = ('department',)
    ordering = ('user__email',)

class InstituteSettingAdmin(admin.ModelAdmin):
    list_display = ('name', 'contact_email', 'contact_phone')
    search_fields = ('name', 'contact_email')
    list_filter = ()
    ordering = ('name',)

admin.site.register(User, UserAdmin)
admin.site.register(StudentProfile, StudentProfileAdmin)
admin.site.register(InstructorProfile, InstructorProfileAdmin)
admin.site.register(InstituteSetting, InstituteSettingAdmin)
