from django.shortcuts import render, redirect
from django.views.generic import TemplateView, CreateView, UpdateView, View
from django.contrib.auth import login, logout, authenticate
from django.contrib.auth.views import LoginView as DjangoLoginView
from django.contrib.auth.mixins import LoginRequiredMixin, UserPassesTestMixin
from django.urls import reverse_lazy
from django.db.models import Avg, Count
from django.contrib import messages
from django.http import JsonResponse
from django.views.decorators.csrf import csrf_exempt
from django.utils.decorators import method_decorator

from .models import User, StudentProfile, InstructorProfile
from .forms import UserSignupForm, UserUpdateForm, StudentProfileForm, InstructorProfileForm

# Helper to log activity without circular dependency issues
def log_user_activity(user, action, details=""):
    from assessments.models import ActivityLog
    ActivityLog.objects.create(user=user, action=action, details=details)

class LandingPageView(TemplateView):
    template_name = 'landing.html'
    
    def get(self, request, *args, **kwargs):
        if request.user.is_authenticated:
            return redirect('dashboard_redirect')
        return super().get(request, *args, **kwargs)

class SignupView(CreateView):
    model = User
    form_class = UserSignupForm
    template_name = 'accounts/signup.html'
    success_url = reverse_lazy('dashboard_redirect')

    def form_valid(self, form):
        user = form.save()
        login(self.request, user)
        log_user_activity(user, "User Sign Up", f"Signed up as {user.role} with email {user.email}")
        messages.success(self.request, f"Welcome, {user.full_name}! Your account has been created.")
        return redirect(self.success_url)

class LoginView(DjangoLoginView):
    template_name = 'accounts/login.html'
    
    def form_valid(self, form):
        response = super().form_valid(form)
        log_user_activity(self.request.user, "User Login", "Logged into the platform")
        messages.success(self.request, f"Welcome back, {self.request.user.full_name}!")
        return response

class LogoutView(View):
    def get(self, request):
        if request.user.is_authenticated:
            log_user_activity(request.user, "User Logout", "Logged out of the platform")
            logout(request)
            messages.info(request, "You have been logged out successfully.")
        return redirect('landing')


@method_decorator(csrf_exempt, name='dispatch')
class SessionLogoutView(View):
    """API endpoint for JavaScript-triggered logout on browser/tab close.
    Accepts POST (with or without CSRF — browser sendBeacon on unload may lose CSRF context).
    Destroys the Django session and logs the user out immediately.
    """
    def post(self, request):
        if request.user.is_authenticated:
            try:
                log_user_activity(request.user, "Session Auto-Logout", "Browser/tab closed — session destroyed automatically.")
            except Exception:
                pass
            logout(request)
        return JsonResponse({'status': 'logged_out'})

class DashboardRedirectView(LoginRequiredMixin, View):
    def get(self, request, *args, **kwargs):
        if request.user.is_superuser or request.user.role == 'admin':
            return redirect('admin_dashboard')
        elif request.user.role == 'instructor':
            return redirect('instructor_dashboard')
        else:
            return redirect('student_dashboard')

class StudentRequiredMixin(LoginRequiredMixin, UserPassesTestMixin):
    def test_func(self):
        return self.request.user.role == 'student'
    
    def handle_no_permission(self):
        messages.error(self.request, "Access Denied: You must be a student to view this page.")
        return redirect('dashboard_redirect')

class InstructorRequiredMixin(LoginRequiredMixin, UserPassesTestMixin):
    def test_func(self):
        return self.request.user.role == 'instructor'
    
    def handle_no_permission(self):
        messages.error(self.request, "Access Denied: You must be an instructor to view this page.")
        return redirect('dashboard_redirect')

class StudentDashboardView(StudentRequiredMixin, TemplateView):
    template_name = 'accounts/student_dashboard.html'

    def get_context_data(self, **kwargs):
        context = super().get_context_data(**kwargs)
        user = self.request.user
        
        # Calculations
        submissions = user.submissions.all()
        total_taken = submissions.count()
        
        # Calculate average score based on completed/malpractice evaluations
        evaluated_submissions = submissions.filter(status__in=['completed', 'malpractice'])
        avg_score = evaluated_submissions.aggregate(Avg('score'))['score__avg'] or 0
        
        pending_evaluations = submissions.filter(status='pending').count()
        recent_submissions = submissions.order_by('-submitted_at')[:5]
        
        context.update({
            'total_taken': total_taken,
            'avg_score': round(avg_score, 1),
            'pending_evaluations': pending_evaluations,
            'recent_submissions': recent_submissions,
        })
        return context

class InstructorDashboardView(InstructorRequiredMixin, TemplateView):
    template_name = 'accounts/instructor_dashboard.html'

    def get_context_data(self, **kwargs):
        context = super().get_context_data(**kwargs)
        user = self.request.user
        
        # Find assessments created by this instructor
        created_assessments = user.created_assessments.all()
        total_created = created_assessments.count()
        
        # Submissions to those assessments
        from assessments.models import Submission, MalpracticeLog
        submissions = Submission.objects.filter(assessment__in=created_assessments)
        total_attempts = submissions.count()
        pending_evaluations = submissions.filter(status='pending').count()
        
        # Malpractice Logs associated with this instructor's assessments (filter/display only TAB, COPY, PASTE)
        malpractice_logs = MalpracticeLog.objects.filter(
            assessment__in=created_assessments,
            event_type__in=['TAB_SWITCH', 'COPY_ATTEMPT', 'PASTE_ATTEMPT']
        ).order_by('-timestamp')
        total_malpractice = malpractice_logs.count()
        recent_malpractice = malpractice_logs[:10]
        
        context.update({
            'total_created': total_created,
            'total_attempts': total_attempts,
            'pending_evaluations': pending_evaluations,
            'recent_attempts': submissions.order_by('-submitted_at')[:5],
            'recent_malpractice': recent_malpractice,
            'total_malpractice': total_malpractice,
        })
        return context

class StudentProfileView(StudentRequiredMixin, View):
    template_name = 'accounts/student_profile.html'

    def get(self, request, *args, **kwargs):
        user_form = UserUpdateForm(instance=request.user)
        profile_form = StudentProfileForm(instance=request.user.student_profile)
        
        return render(request, self.template_name, {
            'user_form': user_form,
            'profile_form': profile_form,
        })

    def post(self, request, *args, **kwargs):
        user_form = UserUpdateForm(request.POST, request.FILES, instance=request.user)
        profile_form = StudentProfileForm(request.POST, instance=request.user.student_profile)
        
        if user_form.is_valid() and profile_form.is_valid():
            user_form.save()
            profile_form.save()
            log_user_activity(request.user, "Update Profile", "Updated student profile details")
            messages.success(request, "Your profile has been updated successfully.")
            return redirect('student_profile')
            
        return render(request, self.template_name, {
            'user_form': user_form,
            'profile_form': profile_form,
        })

class InstructorProfileView(InstructorRequiredMixin, View):
    template_name = 'accounts/instructor_profile.html'

    def get(self, request, *args, **kwargs):
        user_form = UserUpdateForm(instance=request.user)
        profile_form = InstructorProfileForm(instance=request.user.instructor_profile)
        
        from assessments.models import Assessment, Submission
        total_created = Assessment.objects.filter(created_by=request.user).count()
        total_attempts = Submission.objects.filter(assessment__created_by=request.user).count()
        
        return render(request, self.template_name, {
            'user_form': user_form,
            'profile_form': profile_form,
            'total_created': total_created,
            'total_attempts': total_attempts,
        })

    def post(self, request, *args, **kwargs):
        user_form = UserUpdateForm(request.POST, request.FILES, instance=request.user)
        profile_form = InstructorProfileForm(request.POST, instance=request.user.instructor_profile)
        
        if user_form.is_valid() and profile_form.is_valid():
            user_form.save()
            profile_form.save()
            log_user_activity(request.user, "Update Profile", "Updated instructor profile details")
            messages.success(request, "Your profile has been updated successfully.")
            return redirect('instructor_profile')
            
        # Re-fetch stats on form error
        from assessments.models import Assessment, Submission
        total_created = Assessment.objects.filter(created_by=request.user).count()
        total_attempts = Submission.objects.filter(assessment__created_by=request.user).count()
        
        return render(request, self.template_name, {
            'user_form': user_form,
            'profile_form': profile_form,
            'total_created': total_created,
            'total_attempts': total_attempts,
        })

class AdminDashboardView(LoginRequiredMixin, UserPassesTestMixin, TemplateView):
    template_name = 'accounts/admin_dashboard.html'

    def test_func(self):
        return self.request.user.is_superuser or self.request.user.role == 'admin'

    def handle_no_permission(self):
        messages.error(self.request, "Access Denied: You must be an administrator to view this page.")
        return redirect('dashboard_redirect')

    def get_context_data(self, **kwargs):
        context = super().get_context_data(**kwargs)
        from assessments.models import Assessment, Submission, MalpracticeLog
        
        # Stats
        total_users = User.objects.count()
        total_assessments = Assessment.objects.count()
        total_submissions = Submission.objects.count()
        total_malpractice = MalpracticeLog.objects.count()

        # User Management Data
        users_list = User.objects.all().order_by('-date_joined')
        
        # Assessment Overview Data
        assessments_list = Assessment.objects.all().order_by('-created_at')
        
        # Submission Monitoring Data
        submissions_list = Submission.objects.all().order_by('-submitted_at')
        
        # Malpractice Logs
        malpractice_list = MalpracticeLog.objects.all().order_by('-timestamp')

        context.update({
            'total_users': total_users,
            'total_assessments': total_assessments,
            'total_submissions': total_submissions,
            'total_malpractice': total_malpractice,
            'users_list': users_list,
            'assessments_list': assessments_list,
            'submissions_list': submissions_list,
            'malpractice_list': malpractice_list,
        })
        return context

    def post(self, request, *args, **kwargs):
        action = request.POST.get('action')
        user_id = request.POST.get('user_id')
        
        if action and user_id:
            try:
                target_user = User.objects.get(id=user_id)
                if target_user == request.user and action == 'delete':
                    messages.error(request, "You cannot delete your own admin account.")
                elif action == 'toggle_active':
                    target_user.is_active = not target_user.is_active
                    target_user.save()
                    messages.success(request, f"User {target_user.full_name} status updated successfully.")
                elif action == 'change_role':
                    new_role = request.POST.get('role')
                    if new_role in ['student', 'instructor', 'admin']:
                        target_user.role = new_role
                        if new_role == 'admin':
                            target_user.is_staff = True
                        else:
                            target_user.is_staff = False
                        target_user.save()
                        messages.success(request, f"User {target_user.full_name} role updated to {new_role}.")
                elif action == 'delete':
                    target_user.delete()
                    messages.success(request, f"User {target_user.full_name} deleted successfully.")
            except User.DoesNotExist:
                messages.error(request, "Selected user does not exist.")
        
        return redirect('admin_dashboard')
