from django.urls import path
from .views import (
    LandingPageView, SignupView, LoginView, LogoutView, SessionLogoutView,
    DashboardRedirectView, StudentDashboardView, InstructorDashboardView,
    StudentProfileView, InstructorProfileView, AdminDashboardView
)

urlpatterns = [
    path('', LandingPageView.as_view(), name='landing'),
    path('signup/', SignupView.as_view(), name='signup'),
    path('login/', LoginView.as_view(), name='login'),
    path('logout/', LogoutView.as_view(), name='logout'),
    path('session-logout/', SessionLogoutView.as_view(), name='session_logout'),
    path('dashboard/redirect/', DashboardRedirectView.as_view(), name='dashboard_redirect'),
    path('student/dashboard/', StudentDashboardView.as_view(), name='student_dashboard'),
    path('instructor/dashboard/', InstructorDashboardView.as_view(), name='instructor_dashboard'),
    path('admin-dashboard/', AdminDashboardView.as_view(), name='admin_dashboard'),
    path('student/profile/', StudentProfileView.as_view(), name='student_profile'),
    path('instructor/profile/', InstructorProfileView.as_view(), name='instructor_profile'),
]
