from django.test import TestCase
from django.urls import reverse
from django.contrib.auth import get_user_model

User = get_user_model()

class UserAuthenticationTests(TestCase):
    def setUp(self):
        self.signup_url = reverse('signup')
        self.login_url = reverse('login')
        self.redirect_url = reverse('dashboard_redirect')
        
    def test_student_signup_flow(self):
        # Perform signup for a student
        response = self.client.post(self.signup_url, {
            'full_name': 'Test Student',
            'email': 'student@test.com',
            'role': 'student',
            'password': 'password123'
        })
        # Check that it redirected to the dashboard redirect URL (302 redirect)
        self.assertEqual(response.status_code, 302)
        self.assertTrue(response.url.endswith(self.redirect_url))
        
        # Verify student user was created and logged in
        user = User.objects.get(email='student@test.com')
        self.assertEqual(user.full_name, 'Test Student')
        self.assertEqual(user.role, 'student')
        self.assertTrue(hasattr(user, 'student_profile'))
        
    def test_instructor_signup_flow(self):
        # Perform signup for an instructor
        response = self.client.post(self.signup_url, {
            'full_name': 'Test Instructor',
            'email': 'instructor@test.com',
            'role': 'instructor',
            'password': 'password123'
        })
        self.assertEqual(response.status_code, 302)
        self.assertTrue(response.url.endswith(self.redirect_url))
        
        user = User.objects.get(email='instructor@test.com')
        self.assertEqual(user.role, 'instructor')
        self.assertTrue(hasattr(user, 'instructor_profile'))

    def test_email_uniqueness_validation(self):
        # Create a user first
        User.objects.create_user(email='unique@test.com', password='password123', full_name='Unique User', role='student')
        
        # Attempt signup with the same email
        response = self.client.post(self.signup_url, {
            'full_name': 'Another User',
            'email': 'unique@test.com',
            'role': 'student',
            'password': 'password123'
        })
        # Verify signup form raises error and did not redirect
        self.assertEqual(response.status_code, 200)
        form = response.context['form']
        self.assertIn('email', form.errors)
        self.assertEqual(form.errors['email'][0], 'A user with this email address already exists.')

    def test_role_based_redirection_student(self):
        # Log in as student
        user = User.objects.create_user(email='student@test.com', password='password123', full_name='Student User', role='student')
        self.client.login(email='student@test.com', password='password123')
        
        # Access dashboard redirect URL
        response = self.client.get(self.redirect_url)
        self.assertRedirects(response, reverse('student_dashboard'))

    def test_role_based_redirection_instructor(self):
        # Log in as instructor
        user = User.objects.create_user(email='instructor@test.com', password='password123', full_name='Instructor User', role='instructor')
        self.client.login(email='instructor@test.com', password='password123')
        
        # Access dashboard redirect URL
        response = self.client.get(self.redirect_url)
        self.assertRedirects(response, reverse('instructor_dashboard'))
